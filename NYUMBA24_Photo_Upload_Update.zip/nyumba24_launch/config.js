// NYUMBA24 public Supabase client configuration.
// Add the Supabase Publishable key (sb_publishable_...) here. Never use a secret/service_role key.
window.NYUMBA24_CONFIG = {
  SUPABASE_URL: "https://ucsguuvhlxzgpcvtebiu.supabase.co",
  SUPABASE_ANON_KEY: "WEKA_SB_PUBLISHABLE_KEY_HAPA"
};
