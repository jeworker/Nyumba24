-- NYUMBA24 database schema (Supabase / PostgreSQL)
create extension if not exists pgcrypto;

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 5 and 120),
  region text not null default 'Dar es Salaam' check (region = 'Dar es Salaam'),
  area text not null check (char_length(area) between 2 and 100),
  property_type text not null check (property_type in ('Nyumba nzima','Apartment','Chumba','Studio')),
  monthly_rent integer not null check (monthly_rent > 0),
  bedrooms integer not null default 0 check (bedrooms >= 0 and bedrooms <= 30),
  bathrooms integer not null default 0 check (bathrooms >= 0 and bathrooms <= 30),
  contact_phone text not null,
  description text,
  photo_url text,
  photo_urls text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

alter table public.properties add column if not exists photo_urls text[] not null default '{}';
create index if not exists properties_status_created_idx on public.properties(status, created_at desc);
create index if not exists properties_area_idx on public.properties(area);
create index if not exists properties_rent_idx on public.properties(monthly_rent);
alter table public.properties enable row level security;

drop policy if exists "Public can read approved properties" on public.properties;
create policy "Public can read approved properties" on public.properties for select to anon, authenticated using (status = 'approved');
drop policy if exists "Public can submit pending properties" on public.properties;
create policy "Public can submit pending properties" on public.properties for insert to anon, authenticated with check (status = 'pending' and region = 'Dar es Salaam' and monthly_rent > 0);
grant select, insert on public.properties to anon, authenticated;

-- Public image bucket: visitors can view listing images and submit images for review.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('property-photos', 'property-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can upload property photos" on storage.objects;
create policy "Public can upload property photos" on storage.objects for insert to anon, authenticated with check (bucket_id = 'property-photos');
drop policy if exists "Public can view property photos" on storage.objects;
create policy "Public can view property photos" on storage.objects for select to anon, authenticated using (bucket_id = 'property-photos');
