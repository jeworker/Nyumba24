# NYUMBA24

Rental listings website for Dar es Salaam, Tanzania.

## Setup
1. Add the Supabase Publishable key (`sb_publishable_...`) to `config.js` as `SUPABASE_ANON_KEY`. Never put a Supabase Secret or service_role key in browser code.
2. In Supabase SQL Editor, run `supabase/schema.sql`. This creates the properties table, the public `property-photos` bucket, and the required policies.
3. Deploy this repository on Vercel. Vercel redeploys when you push commits to the connected GitHub branch.

## Listing photos
Owners can select up to 6 JPG, PNG, or WebP images, maximum 5 MB each. Images upload to the public `property-photos` Supabase Storage bucket. New listings remain pending until approved by an administrator.
